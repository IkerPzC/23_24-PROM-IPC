package com.example.bbdd1;

import android.provider.BaseColumns;

public final class ContactoContract {

    private ContactoContract() {
    }

    public static class ContactoEntry implements BaseColumns {
        public static final String TABLE_NAME = "contactos";
        public static final String COLUMN_NOMBRE = "nombre";
        public static final String COLUMN_TELEFONO = "telefono";
    }
}

