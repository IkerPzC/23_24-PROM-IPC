package com.example.bbdd1;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextNombre;
    private EditText editTextTelefono;
    private Button btnAgregarContacto;
    private ListView listViewContactos;
    private ArrayAdapter<String> adaptador;
    private ContactoDAO contactoDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextNombre = findViewById(R.id.editTextNombre);
        editTextTelefono = findViewById(R.id.editTextTelefono);
        btnAgregarContacto = findViewById(R.id.btnAgregarContacto);
        listViewContactos = findViewById(R.id.listViewContactos);

        contactoDAO = new ContactoDAO(this);
        contactoDAO.open();

        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listViewContactos.setAdapter(adaptador);

        btnAgregarContacto.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarContacto();
                cargarContactos();
            }
        });

        cargarContactos();
    }

    private void agregarContacto() {
        String nombre = editTextNombre.getText().toString();
        String telefono = editTextTelefono.getText().toString();

        Contacto nuevoContacto = new Contacto();
        nuevoContacto.setNombre(nombre);
        nuevoContacto.setTelefono(telefono);

        contactoDAO.insertarContacto(nuevoContacto);

        // Limpiar los campos después de agregar el contacto
        editTextNombre.getText().clear();
        editTextTelefono.getText().clear();
    }

    private void cargarContactos() {
        adaptador.clear();
        List<Contacto> contactos = contactoDAO.obtenerContactos();

        for (Contacto contacto : contactos) {
            adaptador.add(contacto.getNombre() + " - " + contacto.getTelefono());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        contactoDAO.close();
    }
}