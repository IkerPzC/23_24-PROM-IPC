package com.example.bbdd1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class ContactoDAO {

    private SQLiteDatabase database;
    private ContactoDBHelper dbHelper;

    public ContactoDAO(Context context) {
        dbHelper = new ContactoDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertarContacto(Contacto contacto) {
        ContentValues values = new ContentValues();
        values.put(ContactoContract.ContactoEntry.COLUMN_NOMBRE, contacto.getNombre());
        values.put(ContactoContract.ContactoEntry.COLUMN_TELEFONO, contacto.getTelefono());

        return database.insert(ContactoContract.ContactoEntry.TABLE_NAME, null, values);
    }

    public List<Contacto> obtenerContactos() {
        List<Contacto> contactos = new ArrayList<>();
        String[] projection = {
                ContactoContract.ContactoEntry._ID,
                ContactoContract.ContactoEntry.COLUMN_NOMBRE,
                ContactoContract.ContactoEntry.COLUMN_TELEFONO
        };

        Cursor cursor = database.query(
                ContactoContract.ContactoEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                Contacto contacto = cursorToContacto(cursor);
                contactos.add(contacto);
                cursor.moveToNext();
            }
            cursor.close();
        }

        return contactos;
    }

    private Contacto cursorToContacto(Cursor cursor) {
        Contacto contacto = new Contacto();
        contacto.setId(cursor.getLong(cursor.getColumnIndexOrThrow(ContactoContract.ContactoEntry._ID)));
        contacto.setNombre(cursor.getString(cursor.getColumnIndexOrThrow(ContactoContract.ContactoEntry.COLUMN_NOMBRE)));
        contacto.setTelefono(cursor.getString(cursor.getColumnIndexOrThrow(ContactoContract.ContactoEntry.COLUMN_TELEFONO)));
        return contacto;
    }
}

