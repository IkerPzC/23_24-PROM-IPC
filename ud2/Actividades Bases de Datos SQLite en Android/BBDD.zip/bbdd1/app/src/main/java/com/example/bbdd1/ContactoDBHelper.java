package com.example.bbdd1;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class ContactoDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "agenda.db";
    private static final int DATABASE_VERSION = 1;

    // Sentencia SQL para crear la tabla de contactos
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + ContactoContract.ContactoEntry.TABLE_NAME + " (" +
                    ContactoContract.ContactoEntry._ID + " INTEGER PRIMARY KEY," +
                    ContactoContract.ContactoEntry.COLUMN_NOMBRE + " TEXT," +
                    ContactoContract.ContactoEntry.COLUMN_TELEFONO + " TEXT)";

    // Sentencia SQL para eliminar la tabla de contactos
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + ContactoContract.ContactoEntry.TABLE_NAME;

    public ContactoDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Aquí puedes implementar la lógica para actualizar la base de datos si es necesario
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

