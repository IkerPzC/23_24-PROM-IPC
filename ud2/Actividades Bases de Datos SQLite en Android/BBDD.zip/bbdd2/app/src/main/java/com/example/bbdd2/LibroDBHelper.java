package com.example.bbdd2;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class LibroDBHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "biblioteca.db";
    private static final int DATABASE_VERSION = 1;

    // Sentencia SQL para crear la tabla de libros
    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + LibroContract.LibroEntry.TABLE_NAME + " (" +
                    LibroContract.LibroEntry._ID + " INTEGER PRIMARY KEY," +
                    LibroContract.LibroEntry.COLUMN_TITULO + " TEXT," +
                    LibroContract.LibroEntry.COLUMN_AUTOR + " TEXT," +
                    LibroContract.LibroEntry.COLUMN_PRESTADO + " INTEGER)";

    // Sentencia SQL para eliminar la tabla de libros
    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + LibroContract.LibroEntry.TABLE_NAME;

    public LibroDBHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // Aquí puedes implementar la lógica para actualizar la base de datos si es necesario
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }
}

