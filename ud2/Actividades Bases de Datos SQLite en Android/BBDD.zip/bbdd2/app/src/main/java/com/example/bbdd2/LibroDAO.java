package com.example.bbdd2;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import java.util.ArrayList;
import java.util.List;

public class LibroDAO {

    private SQLiteDatabase database;
    private LibroDBHelper dbHelper;

    public LibroDAO(Context context) {
        dbHelper = new LibroDBHelper(context);
    }

    public void open() throws SQLException {
        database = dbHelper.getWritableDatabase();
    }

    public void close() {
        dbHelper.close();
    }

    public long insertarLibro(Libro libro) {
        ContentValues values = new ContentValues();
        values.put(LibroContract.LibroEntry.COLUMN_TITULO, libro.getTitulo());
        values.put(LibroContract.LibroEntry.COLUMN_AUTOR, libro.getAutor());
        values.put(LibroContract.LibroEntry.COLUMN_PRESTADO, libro.isPrestado() ? 1 : 0);

        return database.insert(LibroContract.LibroEntry.TABLE_NAME, null, values);
    }

    public List<Libro> obtenerLibros() {
        List<Libro> libros = new ArrayList<>();
        String[] projection = {
                LibroContract.LibroEntry._ID,
                LibroContract.LibroEntry.COLUMN_TITULO,
                LibroContract.LibroEntry.COLUMN_AUTOR,
                LibroContract.LibroEntry.COLUMN_PRESTADO
        };

        Cursor cursor = database.query(
                LibroContract.LibroEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                Libro libro = cursorToLibro(cursor);
                libros.add(libro);
                cursor.moveToNext();
            }
            cursor.close();
        }

        return libros;
    }

    private Libro cursorToLibro(Cursor cursor) {
        Libro libro = new Libro();
        libro.setId(cursor.getLong(cursor.getColumnIndexOrThrow(LibroContract.LibroEntry._ID)));
        libro.setTitulo(cursor.getString(cursor.getColumnIndexOrThrow(LibroContract.LibroEntry.COLUMN_TITULO)));
        libro.setAutor(cursor.getString(cursor.getColumnIndexOrThrow(LibroContract.LibroEntry.COLUMN_AUTOR)));
        libro.setPrestado(cursor.getInt(cursor.getColumnIndexOrThrow(LibroContract.LibroEntry.COLUMN_PRESTADO)) == 1);
        return libro;
    }
    public void actualizarEstadoPrestamo(long libroId, boolean prestado) {
        ContentValues values = new ContentValues();
        values.put(LibroContract.LibroEntry.COLUMN_PRESTADO, prestado ? 1 : 0);

        String whereClause = LibroContract.LibroEntry._ID + "=?";
        String[] whereArgs = {String.valueOf(libroId)};

        database.update(LibroContract.LibroEntry.TABLE_NAME, values, whereClause, whereArgs);
    }

    public List<Libro> buscarLibros(String textoBusqueda) {
        List<Libro> librosEncontrados = new ArrayList<>();
        String[] projection = {
                LibroContract.LibroEntry._ID,
                LibroContract.LibroEntry.COLUMN_TITULO,
                LibroContract.LibroEntry.COLUMN_AUTOR,
                LibroContract.LibroEntry.COLUMN_PRESTADO
        };

        String selection = LibroContract.LibroEntry.COLUMN_TITULO + " LIKE ? OR " +
                LibroContract.LibroEntry.COLUMN_AUTOR + " LIKE ?";
        String[] selectionArgs = {"%" + textoBusqueda + "%", "%" + textoBusqueda + "%"};

        Cursor cursor = database.query(
                LibroContract.LibroEntry.TABLE_NAME,
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        if (cursor != null) {
            cursor.moveToFirst();
            while (!cursor.isAfterLast()) {
                Libro libro = cursorToLibro(cursor);
                librosEncontrados.add(libro);
                cursor.moveToNext();
            }
            cursor.close();
        }

        return librosEncontrados;
    }

}

