package com.example.bbdd2;

import android.provider.BaseColumns;

public final class LibroContract {

    private LibroContract() {
    }

    public static class LibroEntry implements BaseColumns {
        public static final String TABLE_NAME = "libros";
        public static final String COLUMN_TITULO = "titulo";
        public static final String COLUMN_AUTOR = "autor";
        public static final String COLUMN_PRESTADO = "prestado";
    }
}

