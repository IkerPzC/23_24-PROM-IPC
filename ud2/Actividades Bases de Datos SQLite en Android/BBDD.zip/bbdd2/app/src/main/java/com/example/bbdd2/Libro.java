package com.example.bbdd2;

public class Libro {
    private long id;
    private String titulo;
    private String autor;
    private boolean prestado;

    public long getId(){
        return id;
    }

    public String getTitulo(){
        return titulo;
    }

    public String getAutor(){
        return autor;
    }

    public boolean isPrestado(){
        return prestado;
    }

    public void setId(long id){
        this.id = id;
    }

    public void setTitulo(String titulo){
        this.titulo = titulo;
    }

    public void setAutor(String autor){
        this.autor = autor;
    }

    public void setPrestado(boolean prestado){
        this.prestado = prestado;
    }

    public String toString() {
        return titulo + " - " + autor + (prestado ? " - prestado" : "");
    }


}

