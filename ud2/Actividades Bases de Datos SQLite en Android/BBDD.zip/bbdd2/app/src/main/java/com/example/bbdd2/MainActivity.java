package com.example.bbdd2;

import android.content.ContentValues;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.app.AlertDialog;
import android.content.DialogInterface;

import androidx.appcompat.app.AppCompatActivity;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText editTextTitulo, editTextAutor, editTextBuscarLibro;
    private Button btnAgregarLibro, btnListarLibros, btnBuscarLibro;
    private ListView listViewLibros;
    private ArrayAdapter<Libro> adaptador;
    private LibroDAO libroDAO;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextTitulo = findViewById(R.id.editTextTitulo);
        editTextAutor = findViewById(R.id.editTextAutor);
        editTextBuscarLibro = findViewById(R.id.editTextBuscarLibro);

        btnAgregarLibro = findViewById(R.id.btnAgregarLibro);
        btnListarLibros = findViewById(R.id.btnListarLibros);
        btnBuscarLibro = findViewById(R.id.btnBuscarLibro);

        listViewLibros = findViewById(R.id.listViewLibros);

        libroDAO = new LibroDAO(this);
        libroDAO.open();

        adaptador = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1);
        listViewLibros.setAdapter(adaptador);

        btnAgregarLibro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                agregarLibro();
                cargarLibros();
            }
        });

        btnListarLibros.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cargarLibros();
            }
        });

        btnBuscarLibro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                buscarLibro();
            }
        });

        listViewLibros.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Libro libroSeleccionado = adaptador.getItem(position);
                mostrarDialogoPrestarLibro(libroSeleccionado);
            }
        });


    }

    private void agregarLibro() {
        String titulo = editTextTitulo.getText().toString();
        String autor = editTextAutor.getText().toString();

        Libro nuevoLibro = new Libro();
        nuevoLibro.setTitulo(titulo);
        nuevoLibro.setAutor(autor);

        libroDAO.insertarLibro(nuevoLibro);

        // Limpiar los campos después de agregar el libro
        editTextTitulo.getText().clear();
        editTextAutor.getText().clear();
    }

    private void cargarLibros() {
        adaptador.clear();
        List<Libro> libros = libroDAO.obtenerLibros();

        for (Libro libro : libros) {
            adaptador.add(libro);
        }
    }

    private void buscarLibro() {
        String buscarTexto = editTextBuscarLibro.getText().toString();

        // Obtener la lista de libros que coinciden con el texto de búsqueda
        List<Libro> librosEncontrados = libroDAO.buscarLibros(buscarTexto);

        // Limpiar la lista actual en el adaptador
        adaptador.clear();

        if (!librosEncontrados.isEmpty()) {
            // Mostrar los libros encontrados en la lista
            for (Libro libro : librosEncontrados) {
                adaptador.add(libro);
            }
        } else {
            // Mostrar un Toast si no se encontraron libros
            Toast.makeText(this, "No se encontraron libros con el texto '" + buscarTexto + "'", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        libroDAO.close();
    }

    private void prestarLibro(Libro libro) {
        libroDAO.actualizarEstadoPrestamo(libro.getId(), true);
        cargarLibros();
    }

    private void mostrarDialogoPrestarLibro(final Libro libro) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Prestar Libro");
        builder.setMessage("¿Quieres prestar el libro '" + libro.getTitulo() + "'?");
        builder.setPositiveButton("Sí", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                prestarLibro(libro);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // No hacer nada o mostrar un mensaje, según tus necesidades
            }
        });
        builder.show();
    }
}
