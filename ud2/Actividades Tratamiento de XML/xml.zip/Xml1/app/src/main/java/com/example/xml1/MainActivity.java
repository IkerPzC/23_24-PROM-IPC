package com.example.xml1;
import android.content.Intent;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import androidx.appcompat.app.AppCompatActivity;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public class MainActivity extends AppCompatActivity {

    private static final String[] RSS_FEED_URLS = {
            "https://feeds.bbci.co.uk/news/rss.xml",
            "https://feeds.bbci.co.uk/news/technology/rss.xml"
    };

    private ArrayList<NewsItem> newsItems;
    private ArrayAdapter<NewsItem> arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        newsItems = new ArrayList<>();
        arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_2, android.R.id.text1, newsItems);

        ListView listView = findViewById(R.id.listView);
        listView.setAdapter(arrayAdapter);

        // Agregar el OnItemClickListener
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                // Obtener la URL de la noticia seleccionada
                String newsLink = newsItems.get(position).getLink();

                // Abrir el navegador web con la URL
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(newsLink));
                startActivity(browserIntent);
            }
        });

        new FetchRssTask().execute(RSS_FEED_URLS);
    }

    private class FetchRssTask extends AsyncTask<String, Void, Void> {

        @Override
        protected Void doInBackground(String... urls) {
            for (String url : urls) {
                try {
                    URL feedUrl = new URL(url);
                    HttpURLConnection connection = (HttpURLConnection) feedUrl.openConnection();
                    connection.setRequestMethod("GET");
                    InputStream inputStream = connection.getInputStream();

                    DocumentBuilderFactory documentBuilderFactory = DocumentBuilderFactory.newInstance();
                    DocumentBuilder documentBuilder = documentBuilderFactory.newDocumentBuilder();
                    Document document = documentBuilder.parse(inputStream);

                    NodeList itemList = document.getElementsByTagName("item");

                    for (int i = 0; i < itemList.getLength(); i++) {
                        Node itemNode = itemList.item(i);

                        if (itemNode.getNodeType() == Node.ELEMENT_NODE) {
                            Element itemElement = (Element) itemNode;

                            String title = itemElement.getElementsByTagName("title").item(0).getTextContent();
                            String link = itemElement.getElementsByTagName("link").item(0).getTextContent();
                            String description = itemElement.getElementsByTagName("description").item(0).getTextContent();

                            NewsItem newsItem = new NewsItem(title, link, description);
                            newsItems.add(newsItem);
                        }
                    }

                    connection.disconnect();
                } catch (Exception e) {
                    Log.e("Error", e.getMessage());
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            arrayAdapter.notifyDataSetChanged();
        }
    }
}