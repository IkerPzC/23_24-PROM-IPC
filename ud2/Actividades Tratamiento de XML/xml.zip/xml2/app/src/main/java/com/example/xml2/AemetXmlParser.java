package com.example.xml2;

import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class AemetXmlParser {

    public List<InformacionMeteorologica> parsearXML(String url) throws Exception {
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        try (InputStream inputStream = new URL(url).openStream()) {
            parser.setInput(inputStream, null);
            return procesarParsing(parser);
        }
    }

    private List<InformacionMeteorologica> procesarParsing(XmlPullParser parser) throws Exception {
        List<InformacionMeteorologica> informacionDias = new ArrayList<>();
        int eventType = parser.getEventType();
        boolean esPrimerDia = true;

        while (eventType != XmlPullParser.END_DOCUMENT) {
            String nombreEtiqueta = null;

            switch (eventType) {
                case XmlPullParser.START_TAG:
                    nombreEtiqueta = parser.getName();

                    if (esPrimerDia && "dia".equals(nombreEtiqueta)) {
                        InformacionMeteorologica infoDia = parsearDia(parser);
                        informacionDias.add(infoDia);
                        esPrimerDia = false;
                    }
                    break;
            }

            eventType = parser.next();
        }

        return informacionDias;
    }

    private InformacionMeteorologica parsearDia(XmlPullParser parser) throws Exception {
        String estadoCielo = null;
        String temperatura = null;
        String humedadRelativa = null;
        String direccionViento = null;
        String velocidadViento = null;
        int eventType = parser.getEventType();

        while (eventType != XmlPullParser.END_TAG || !"dia".equals(parser.getName())) {
            String nombreEtiqueta = null;

            switch (eventType) {
                case XmlPullParser.START_TAG:
                    nombreEtiqueta = parser.getName();

                    if ("estado_cielo".equals(nombreEtiqueta)) {
                        estadoCielo = parser.getAttributeValue(null, "descripcion");
                    } else if ("temperatura".equals(nombreEtiqueta)) {
                        temperatura = parser.nextText();
                    } else if ("humedad_relativa".equals(nombreEtiqueta)) {
                        humedadRelativa = parser.nextText();
                    } else if ("viento".equals(nombreEtiqueta)) {
                        direccionViento = obtenerTextoHijo(parser, "direccion");
                        velocidadViento = obtenerTextoHijo(parser, "velocidad");
                    }
                    break;
            }

            eventType = parser.next();
        }

        return new InformacionMeteorologica(temperatura, estadoCielo, humedadRelativa, direccionViento, velocidadViento);
    }

    private String obtenerTextoHijo(XmlPullParser parser, String nombreEtiquetaHijo) throws Exception {
        while (parser.next() != XmlPullParser.START_TAG
                || !nombreEtiquetaHijo.equals(parser.getName())) {}
        String texto = parser.nextText();
        parser.nextTag();
        return texto;
    }
}