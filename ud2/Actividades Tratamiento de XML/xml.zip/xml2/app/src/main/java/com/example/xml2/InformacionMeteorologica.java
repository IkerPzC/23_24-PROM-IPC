package com.example.xml2;

public class InformacionMeteorologica {
    private String temperatura;
    private String estadoCielo;
    private String humedadRelativa;
    private String direccionViento;
    private String velocidadViento;

    public InformacionMeteorologica(String temperatura, String estadoCielo, String humedadRelativa, String direccionViento, String velocidadViento) {
        this.temperatura = temperatura;
        this.estadoCielo = estadoCielo;
        this.humedadRelativa = humedadRelativa;
        this.direccionViento = direccionViento;
        this.velocidadViento = velocidadViento;
    }

    public String getTemperatura() {
        return temperatura;
    }

    public String getEstadoCielo() {
        return estadoCielo;
    }

    public String getHumedadRelativa() {
        return humedadRelativa;
    }

    public String getDireccionViento() {
        return direccionViento;
    }

    public String getVelocidadViento() {
        return velocidadViento;
    }
}