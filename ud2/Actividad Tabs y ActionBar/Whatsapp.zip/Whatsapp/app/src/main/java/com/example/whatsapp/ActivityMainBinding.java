package com.example.whatsapp;

import android.view.LayoutInflater;
import android.view.View;
import androidx.appcompat.widget.Toolbar;

public class ActivityMainBinding {
    public Toolbar toolbar;
    private View rootView;

    private ActivityMainBinding(View rootView) {
        this.rootView = rootView;
        //this.toolbar = rootView.findViewById(R.id.toolbar);
    }

    public static ActivityMainBinding inflate(LayoutInflater layoutInflater) {
        View rootView = layoutInflater.inflate(R.layout.activity_main, null, false);
        return new ActivityMainBinding(rootView);
    }

    public View getRoot() {
        return rootView;
    }
}

