package com.example.whatsapp;

import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;

import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;


import com.example.whatsapp.ActivityMainBinding;
import com.google.android.material.tabs.TabLayout;


public class MainActivity extends AppCompatActivity {

    private ViewPager viewPager;
    private Contacto[] datosContacto;
    private Estado[] datosEstados;
    private Llamada[] datosLlamadas;
    private ListView listaChats, listaEstados, listaLlamadas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        cargarDatos();

        ActivityMainBinding binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        //setSupportActionBar(binding.toolbar);

        viewPager = findViewById(R.id.viewpager);
        viewPager.setAdapter(new PageAdapter());

        TabLayout tabLayout = findViewById(R.id.tabLayout);
        tabLayout.setTabMode(TabLayout.MODE_FIXED);
        tabLayout.setupWithViewPager(viewPager);

    }

    private void cargarDatos()  {
        ImageView imagenPellistri = new ImageView(this);
        imagenPellistri.setImageResource(R.drawable.pellistri);

        ImageView imagenMessi = new ImageView(this);
        imagenMessi.setImageResource(R.drawable.messi);

        ImageView imagenChechu = new ImageView(this);
        imagenChechu.setImageResource(R.drawable.chechu);

        ImageView imagenJimmy = new ImageView(this);
        imagenJimmy.setImageResource(R.drawable.jimmy);

        ImageView imagenAlaves = new ImageView(this);
        imagenAlaves.setImageResource(R.drawable.alaves);

        ImageView imagenFlorentino = new ImageView(this);
        imagenFlorentino.setImageResource(R.drawable.florentino);

        ImageView imagenLimon = new ImageView(this);
        imagenLimon.setImageResource(R.drawable.limon);

        ImageView imagenMama = new ImageView(this);
        imagenMama.setImageResource(R.drawable.mama);

        ImageView imagenHospital = new ImageView(this);
        imagenHospital.setImageResource(R.drawable.hospital);

        datosContacto = new Contacto[] {
                new Contacto("Médico Limonsito", "Su novia tiene gonorrea, utilizan protección? Debe acudir a la consulta", "10:28", imagenHospital),
                new Contacto("Mama", "Me ha llamado tu novia llorando, qué le has hecho?", "10:25", imagenMama),
                new Contacto("Limonsito ♡", "Tu: Amor, me voy a jugar con Messi, ve sola al hospital", "10:20", imagenLimon),
                new Contacto("Leo Messi", "Vamos al entreno, traete la pelota. Viste que le quite el Balón de oro al facu?", "10:04", imagenMessi),
                new Contacto("Deportivo Alavés", "No te podemos arreglar las goteras, cuesta dinero", "02/11/2023", imagenAlaves),
                new Contacto("Chechu Informático", "No funsiona moodle? Cuando yo lo hise funsionaba", "01/11/2023", imagenChechu),
                new Contacto("Florentino Pérez", "El Bernabeu no se paga solo, nos dejamos ganar por 2.000.000€", "29/10/2023", imagenFlorentino),
                new Contacto("Jimmy Guarrindongo", "Tu hermana tiene mejores curvas que el circuito de mónaco", "28/10/2023", imagenJimmy),
                new Contacto("Facundo Pellistri", "Anoté gol, lo vio? Le aviso cuando anote de nuevo", "12/07/2007", imagenPellistri)
        };

        datosEstados = new Estado[] {
                new Estado("Mama", imagenMama),
                new Estado("Limonsito ♡", imagenLimon),
                new Estado("Leo Messi", imagenMessi),
                new Estado("Deportivo Alavés", imagenAlaves),
                new Estado("Chechu Informático", imagenChechu),
                new Estado("Florentino Pérez", imagenFlorentino),
                new Estado("Jimmy Guarrindongo", imagenJimmy),
                new Estado("Facundo Pellistri", imagenPellistri)
        };

        datosLlamadas = new Llamada[] {
                new Llamada("Leo Messi", "2 de noviembre 21:25", true, imagenMessi, this),
                new Llamada("Jimmy Guarrindongo", "1 de noviembre 11:50", false, imagenJimmy, this),
                new Llamada("Florentino Pérez", "29 de octubre 16:52", true, imagenFlorentino, this),
                new Llamada("Deportivo Alavés", "12 de octubre 12:31", true, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "12 de octubre 10:44", false, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "5 de septiembre 08:11", true, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "25 de agosto 23:51", true, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "31 de julio 20:47", true, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "22 de julio 13:11", true, imagenAlaves, this),
                new Llamada("Deportivo Alavés", "17 de julio 23:51", true, imagenAlaves, this),
                new Llamada("Facundo Pellistri", "12/07/07 21:44", false, imagenPellistri, this)
        };
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    class PageAdapter extends PagerAdapter {
        private LinearLayout pestana1, pestana2, pestana3;
        private final int[] pestanas ={R.string.tab1, R.string.tab2, R.string.tab3};

        @Override
        public int getCount() {
            return 3;
        }
        @Nullable
        @Override
        public CharSequence getPageTitle(int position) {
            return getString(pestanas[position]);
        }
        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            View page;
            switch (position) {
                case 0:
                    if (pestana1 == null) {
                        pestana1 = (LinearLayout) LayoutInflater.from(MainActivity.this).inflate(R.layout.tab1, container, false);
                    }
                    page = pestana1;
                    listaChats = (ListView) pestana1.findViewById(R.id.listaChats);
                    AdaptadorContacto adaptadorContacto = new AdaptadorContacto(pestana1.getContext(), datosContacto);
                    listaChats.setAdapter(adaptadorContacto);
                    break;
                case 1:
                    if (pestana2 == null) {
                        pestana2 = (LinearLayout) LayoutInflater.from(MainActivity.this).inflate(R.layout.tab2,container,false);
                    }
                    page=pestana2;
                    listaEstados = (ListView) pestana2.findViewById(R.id.listaEstados);
                    AdaptadorEstados adaptadorEstados = new AdaptadorEstados(pestana2.getContext(), datosEstados);
                    listaEstados.setAdapter(adaptadorEstados);
                    break;
                default:
                    if (pestana3 == null) {
                        pestana3 = (LinearLayout) LayoutInflater.from(MainActivity.this).inflate(R.layout.tab3,container,false);
                    }
                    page=pestana3;
                    listaLlamadas = (ListView) pestana3.findViewById(R.id.listaLlamadas);
                    AdaptadorLlamada adaptadorLlamada = new AdaptadorLlamada(pestana3.getContext(), datosLlamadas);
                    listaLlamadas.setAdapter(adaptadorLlamada);
                    break;
            }
            container.addView(page, 0);
            return page;
        }

        @Override
        public boolean isViewFromObject(@NonNull View view, @NonNull Object object) {
            return view == object;
        }

        @Override
        public void destroyItem(@NonNull ViewGroup container, int position, @NonNull Object object) {
            container.removeView((View)object);
        }
    }
}