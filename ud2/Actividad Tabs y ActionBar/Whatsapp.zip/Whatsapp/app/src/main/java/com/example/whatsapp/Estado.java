package com.example.whatsapp;

import android.widget.ImageView;

public class Estado {

    private String nombre;
    private ImageView img;

    public Estado(String nombre, ImageView img) {
        this.nombre = nombre;

        this.img = img;
    }

    public String getNombre() {
        return nombre;
    }

    public ImageView getImg() {
        return img;
    }
}
