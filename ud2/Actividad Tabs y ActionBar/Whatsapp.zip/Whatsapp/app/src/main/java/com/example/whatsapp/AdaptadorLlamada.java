package com.example.whatsapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class AdaptadorLlamada extends ArrayAdapter<Llamada> {

    private Llamada[] datos;

    public AdaptadorLlamada(@NonNull Context context, Llamada[] datos) {
        super(context, R.layout.estados_layout, datos);
        this.datos = datos;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View item = inflater.inflate(R.layout.llamadas_layout, null);

        TextView nombre = (TextView) item.findViewById(R.id.nombre);
        nombre.setText(datos[position].getNombre());

        TextView fecha = (TextView) item.findViewById(R.id.fecha);
        fecha.setText(datos[position].getFecha());

        ImageView img = (ImageView) item.findViewById(R.id.imagen);
        img.setImageDrawable(datos[position].getImg().getDrawable());

        ImageView recibida = (ImageView) item.findViewById(R.id.recibida);
        recibida.setImageDrawable(datos[position].getLlamada().getDrawable());

        return item;
    }
}
