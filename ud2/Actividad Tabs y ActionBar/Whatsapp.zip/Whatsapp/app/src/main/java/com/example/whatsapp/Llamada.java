package com.example.whatsapp;

import android.content.Context;
import android.widget.ImageView;

public class Llamada {

    private String nombre, fecha;
    private ImageView img, llamada;

    public Llamada(String nombre, String fecha, boolean recibida, ImageView img, Context contexto) {
        this.nombre = nombre;
        this.fecha = fecha;
        llamada = new ImageView(contexto);
        if(recibida) {
            llamada.setImageResource(R.drawable.recived);
        }
        else {
            llamada.setImageResource(R.drawable.made);
        }
        this.img = img;
    }

    public String getNombre() {
        return nombre;
    }

    public String getFecha() {
        return fecha;
    }

    public ImageView getImg() {
        return img;
    }

    public ImageView getLlamada() { return llamada; }
}
