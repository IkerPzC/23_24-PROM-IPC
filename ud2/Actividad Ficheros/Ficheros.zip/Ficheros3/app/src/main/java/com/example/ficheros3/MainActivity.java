package com.example.ficheros3;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private ListView listViewWebs;
    private List<WebModel> webList;

    private ImageView imageViewBottom;
    private long lastClickTime = 0;
    private Handler handler = new Handler();

    private boolean itemClickEnabled = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        listViewWebs = findViewById(R.id.listViewWebs);
        webList = cargarWebsDesdeRecurso(R.raw.webs);
        imageViewBottom = findViewById(R.id.imageViewBottom);

        ArrayAdapter<WebModel> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, webList);
        listViewWebs.setAdapter(adapter);

        // Manejar clics en la lista
        listViewWebs.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                WebModel web = webList.get(position);

                // Actualizar la imagen del ImageView
                ImageView imageViewBottom = findViewById(R.id.imageViewBottom);
                imageViewBottom.setImageResource(getResources().getIdentifier(web.getLogo(), "drawable", getPackageName()));

                // Agregar un retraso de 2 segundos antes de hacer el Intent
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        // Crear un Intent para abrir el enlace en un navegador web
                        Intent intent = new Intent(Intent.ACTION_VIEW);
                        intent.setData(Uri.parse(web.getEnlace()));

                        // Verificar si hay una aplicación para manejar el Intent antes de iniciarlo
                        if (intent.resolveActivity(getPackageManager()) != null) {
                            startActivity(intent);
                        } else {
                            // Manejar el caso en el que no hay aplicación para manejar el Intent
                            Toast.makeText(MainActivity.this, "No hay aplicación para abrir el enlace", Toast.LENGTH_SHORT).show();
                        }
                    }
                }, 300); // 2000 milisegundos (2 segundos)

                // Actualizar el tiempo del último clic
                lastClickTime = System.currentTimeMillis();
            }
        });

    }

    private List<WebModel> cargarWebsDesdeRecurso(int resourceId) {
        List<WebModel> websList = new ArrayList<>();

        try {
            // Abrir el flujo de entrada para el recurso
            InputStream inputStream = getResources().openRawResource(resourceId);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            // Leer el contenido del recurso línea por línea
            String line;
            while ((line = reader.readLine()) != null) {
                // Separar los campos utilizando el punto y coma como delimitador
                String[] parts = line.split(";");

                // Crear un objeto WebModel y agregarlo a la lista
                if (parts.length == 4) {
                    String nombre = parts[0].trim();
                    String enlace = parts[1].trim();
                    String logo = parts[2].trim();
                    int identificador = Integer.parseInt(parts[3].trim());

                    WebModel web = new WebModel(nombre, enlace, logo, identificador);
                    websList.add(web);
                }
            }

            // Cerrar el flujo de entrada
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return websList;
    }
}
