package com.example.ficheros1;

import android.content.Context;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {

    private TextView textViewContenidoFichero;
    private EditText editTextContenido;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewContenidoFichero = findViewById(R.id.textViewContenidoFichero);
        editTextContenido = findViewById(R.id.editTextContenido);
    }
    public void onClickAnadirFichINT(View view) {
        String contenido = editTextContenido.getText().toString();
        String fileName = "ficheroInterno.txt";

        try {
            FileOutputStream fos = openFileOutput(fileName, Context.MODE_PRIVATE);
            fos.write(contenido.getBytes());
            fos.close();
            editTextContenido.setText("");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onClickAnadirFichEXT(View view) {
        String contenido = editTextContenido.getText().toString();
        String fileName = "ficheroExterno.txt";
        editTextContenido.setText("");
        // Obtener el directorio de almacenamiento externo
        File externalStorageDir = Environment.getExternalStorageDirectory();

        // Crear una referencia al archivo en el directorio externo
        File file = new File(externalStorageDir, fileName);

        try {
            // Crear el flujo de salida para el archivo externo
            FileOutputStream fos = new FileOutputStream(file);

            // Escribir el contenido en el archivo
            fos.write(contenido.getBytes());

            // Cerrar el flujo de salida
            fos.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void onClickLeerFichINT(View view) {
        String fileName = "ficheroInterno.txt";
        StringBuilder contenido = new StringBuilder();

        try {
            FileInputStream fis = openFileInput(fileName);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));
            String line;
            while ((line = reader.readLine()) != null) {
                contenido.append(line).append("\n");
            }
            fis.close();
            textViewContenidoFichero.setText(contenido.toString());
        } catch (IOException e) {
            e.printStackTrace();
            textViewContenidoFichero.setText("Error al leer el fichero interno");
        }
    }

    public void onClickLeerFichEXT(View view) {
        String fileName = "ficheroExterno.txt";

        // Obtener el directorio de almacenamiento externo
        File externalStorageDir = Environment.getExternalStorageDirectory();

        // Crear una referencia al archivo en el directorio externo
        File file = new File(externalStorageDir, fileName);

        try {
            // Crear el flujo de entrada para el archivo externo
            FileInputStream fis = new FileInputStream(file);
            BufferedReader reader = new BufferedReader(new InputStreamReader(fis));

            // Leer el contenido del archivo línea por línea
            StringBuilder contenido = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                contenido.append(line).append("\n");
            }

            // Cerrar el flujo de entrada
            fis.close();

            // Mostrar el contenido en el TextView
            textViewContenidoFichero.setText(contenido.toString());
        } catch (IOException e) {
            e.printStackTrace();
            textViewContenidoFichero.setText("Error al leer el fichero externo");
        }
    }

    public void onClickLeerRecurso(View view) {
        // Obtener el identificador del recurso
        int resourceId = R.raw.txipiron;

        // Obtener un objeto Resources
        Resources resources = getResources();

        // Abrir el flujo de entrada para el recurso
        InputStream inputStream = resources.openRawResource(resourceId);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

        // Leer el contenido del recurso línea por línea
        StringBuilder contenido = new StringBuilder();
        try {
            String line;
            while ((line = reader.readLine()) != null) {
                contenido.append(line).append("\n");
            }
            // Cerrar el flujo de entrada
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            textViewContenidoFichero.setText("Error al leer el recurso");
            return;
        }

        // Mostrar el contenido en el TextView
        textViewContenidoFichero.setText(contenido.toString());
    }

    public void onClickBorrarFichINT(View view) {
        String fileName = "ficheroInterno.txt";

        // Obtener el contexto para acceder a los archivos internos
        Context context = getApplicationContext();

        // Borrar el fichero interno
        boolean deleted = context.deleteFile(fileName);

        // Mostrar el resultado en el TextView
        if (deleted) {
            textViewContenidoFichero.setText("Fichero interno borrado exitosamente");
        } else {
            textViewContenidoFichero.setText("Error al borrar el fichero interno");
        }
    }

    public void onClickBorrarFichEXT(View view) {
        String fileName = "ficheroExterno.txt";

        // Obtener el directorio de almacenamiento externo
        File externalStorageDir = Environment.getExternalStorageDirectory();

        // Crear una referencia al archivo en el directorio externo
        File file = new File(externalStorageDir, fileName);

        // Borrar el fichero externo
        boolean deleted = file.delete();

        // Mostrar el resultado en el TextView
        if (deleted) {
            textViewContenidoFichero.setText("Fichero externo borrado exitosamente");
        } else {
            textViewContenidoFichero.setText("Error al borrar el fichero externo");
        }
    }
}
