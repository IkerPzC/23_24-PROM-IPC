package com.example.ficheros2;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import androidx.appcompat.app.AppCompatActivity;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Spinner spinnerProvincias = findViewById(R.id.spinnerProvincias);

        // Cargar los nombres de provincias desde el archivo de recurso
        List<String> provinciasList = cargarProvinciasDesdeRecurso(R.raw.provinsias);

        // Crear un ArrayAdapter y establecerlo en el Spinner
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, provinciasList);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerProvincias.setAdapter(adapter);

        // Manejar la selección del Spinner
        spinnerProvincias.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parentView, View selectedItemView, int position, long id) {
                String selectedProvincia = (String) parentView.getItemAtPosition(position);
                // Puedes hacer algo con la provincia seleccionada
            }

            @Override
            public void onNothingSelected(AdapterView<?> parentView) {
                // Manejar el caso en que no se ha seleccionado nada
            }
        });
    }

    private List<String> cargarProvinciasDesdeRecurso(int resourceId) {
        List<String> provinciasList = new ArrayList<>();

        try {
            // Abrir el flujo de entrada para el recurso
            InputStream inputStream = getResources().openRawResource(resourceId);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));

            // Leer el contenido del recurso línea por línea
            String line;
            while ((line = reader.readLine()) != null) {
                provinciasList.add(line);
            }

            // Cerrar el flujo de entrada
            inputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return provinciasList;
    }
}