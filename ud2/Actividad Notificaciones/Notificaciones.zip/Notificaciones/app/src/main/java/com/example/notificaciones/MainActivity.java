package com.example.notificaciones;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    private static final int REQUEST_CODE = 123;
    private static final int REQUEST_CODE_NOTIFICATION = 456;
    private int score = 0;
    private EditText editAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Verificar y solicitar permisos
        checkAndRequestPermission();
        generateRandomNumbersAndOperator();

        // Inicializar el EditText
        editAnswer = findViewById(R.id.editAnswer);
    }

    private void checkAndRequestPermission() {
        // Verificar si tienes el permiso necesario
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.INTERNET) == PackageManager.PERMISSION_GRANTED) {

        } else {
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.INTERNET}, REQUEST_CODE);
        }
    }

    public void checkAnswer(View view) {
        // Lógica para comprobar la respuesta del usuario
        // Incrementar el contador de aciertos si la respuesta es correcta

        if (isUserAnswerValid()) {
            if (isAnswerCorrect()) {
                score++;
                updateScore();
                if (score == 10) {
                    showNotification();
                    score = 0; // Reiniciar el contador de aciertos
                    updateScore();
                }
            }
        } else {
            // Muestra un mensaje al usuario indicando que debe ingresar un número válido.
            // Puedes usar Toast o algún otro mecanismo de retroalimentación.
            // Aquí un ejemplo usando Toast:
            Toast.makeText(this, "Por favor, ingrese un número válido.", Toast.LENGTH_SHORT).show();
        }

        // Generar nuevos números y operador para la siguiente pregunta
        generateRandomNumbersAndOperator();

        // Vaciar el campo de texto del usuario
        editAnswer.setText("");
    }

    private boolean isUserAnswerValid() {
        // Verifica si el campo de texto del usuario contiene un número válido
        String userAnswerString = editAnswer.getText().toString();

        // Comprueba si la cadena no está vacía y si es un número válido (entero o decimal)
        return !TextUtils.isEmpty(userAnswerString) && isValidAnswer(userAnswerString);
    }

    private boolean isValidAnswer(String str) {
        try {
            // Intenta convertir la cadena a un número
            Double.parseDouble(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

    private boolean isAnswerCorrect() {
        // Lógica para comprobar si la respuesta del usuario es correcta
        String userAnswerString = editAnswer.getText().toString();

        // En este caso, simplemente verificamos que la respuesta sea un número válido
        return isValidAnswer(userAnswerString);
    }

    private void generateRandomNumbersAndOperator() {
        TextView textNumber1 = findViewById(R.id.textNumber1);
        TextView textNumber2 = findViewById(R.id.textNumber2);
        TextView textOperator = findViewById(R.id.textOperator);

        Random random = new Random();

        int number1 = random.nextInt(100) + 1;
        int number2 = random.nextInt(100) + 1;

        textNumber1.setText(String.valueOf(number1));
        textNumber2.setText(String.valueOf(number2));

        // Generar un operador aleatorio
        String operator;
        int operatorCode = random.nextInt(4);
        switch (operatorCode) {
            case 0:
                operator = "+";
                break;
            case 1:
                operator = "-";
                break;
            case 2:
                operator = "x"; // Usar "x" en lugar de "X" para representar la multiplicación
                break;
            case 3:
                operator = ":";
                break;
            default:
                operator = "+"; // Por defecto, usar la suma
        }

        textOperator.setText(operator);
    }

    private void updateScore() {
        TextView textScore = findViewById(R.id.textScore);
        textScore.setText("Aciertos: " + score);
    }

    private void showNotification() {
        // Crear un canal de notificación para dispositivos Android Oreo y versiones posteriores
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "channel_id",
                    "Channel Name",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(channel);
        }

        // Obtener el icono personalizado
        int iconResourceId = R.drawable.tick;

        // Crear un Intent para abrir la pantalla principal
        Intent intent = new Intent(this, MainActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent, PendingIntent.FLAG_IMMUTABLE);

        // Crear y mostrar la notificación con el PendingIntent actualizado
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "channel_id")
                .setSmallIcon(iconResourceId)
                .setContentTitle("¡Has acertado 10 veces!")
                .setContentText("Haz clic para volver a empezar.")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setContentIntent(pendingIntent)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        notificationManager.notify(1, builder.build());
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_CODE) {
            // Verificar si el usuario otorgó el permiso
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // El usuario otorgó el permiso, realiza la operación que requiere permisos aquí
                // ...
            } else {
                // El usuario denegó el permiso, puedes mostrar un mensaje o deshabilitar la funcionalidad relacionada con el permiso
            }
        } else if (requestCode == REQUEST_CODE_NOTIFICATION) {
            // Verificar si el usuario otorgó el permiso de notificación
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // El usuario otorgó el permiso de notificación, muestra la notificación
                showNotification();
            } else {
                // El usuario denegó el permiso de notificación, puedes mostrar un mensaje o manejarlo según tus necesidades
                Toast.makeText(this, "Se requieren permisos para mostrar notificaciones.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
