package com.example.dialogos;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Mostrar el diálogo de inicio de sesión al iniciar la aplicación
        showLoginDialog();

        // Obtener el botón "Salir" y configurar el OnClickListener
        Button exitButton = findViewById(R.id.exitButton);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showExitConfirmationDialog();
            }
        });
    }

    private void showLoginDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("LOGIN");

        // Configurar el contenido del diálogo (sin utilizar layout XML)
        final EditText usernameEditText = new EditText(this);
        usernameEditText.setHint("Usuario");
        final EditText passwordEditText = new EditText(this);
        passwordEditText.setHint("Password");
        passwordEditText.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);

        // Agregar las vistas al diseño del diálogo
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.addView(usernameEditText);
        layout.addView(passwordEditText);

        builder.setView(layout);
        builder.setCancelable(false);  // Hacer el diálogo modal

        builder.setPositiveButton("LOGIN", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                // Obtener los valores ingresados por el usuario
                String enteredUsername = usernameEditText.getText().toString();
                String enteredPassword = passwordEditText.getText().toString();

                // Verificar las credenciales
                if (isValidCredentials(enteredUsername, enteredPassword)) {
                    // Credenciales válidas, realizar acciones necesarias
                    Toast.makeText(getApplicationContext(), "LOGIN CORRECTO", Toast.LENGTH_SHORT).show();
                } else {
                    // Credenciales incorrectas, mostrar el diálogo nuevamente
                    Toast.makeText(getApplicationContext(), "Usuario o contraseña INCORRECTOS", Toast.LENGTH_SHORT).show();
                    showLoginDialog();
                }
            }
        });

        builder.show();
    }

    private boolean isValidCredentials(String username, String password) {
        return username.equals("usuario1") && password.equals("123456");
    }

    private void showExitConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("¿Desea Salir?")
                .setTitle("Confirmación");

        builder.setCancelable(false);  // Hacer el diálogo modal

        builder.setPositiveButton("ACEPTAR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.i("Dialogos", "ADIOS");
                        finish();
                    }
                })
                .setNegativeButton("CANCELAR", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Log.i("Dialogos", "SE QUEDA");
                    }
                });

        builder.show();
    }
}