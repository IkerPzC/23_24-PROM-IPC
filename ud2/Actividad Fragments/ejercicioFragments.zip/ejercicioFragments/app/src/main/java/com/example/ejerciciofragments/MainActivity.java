package com.example.ejerciciofragments;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class MainActivity extends AppCompatActivity implements FragmentListado.PlatoListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        FragmentListado fragmentListado = (FragmentListado)
                getSupportFragmentManager().findFragmentById(R.id.frgListado);
        fragmentListado.setPlatoListener(this);
    }

    @Override
    public void onPlatoSeleccionado(Plato c) {
        boolean hayDetalle = (getSupportFragmentManager().
                findFragmentById(R.id.frgDetalle)!= null);
        if (hayDetalle) {
            ((FragmentDetalle)getSupportFragmentManager().
                    findFragmentById(R.id.frgDetalle)).
                    mostrarDetalle(c.getReceta());
        }
        else {
            Intent i = new Intent(this, DetalleActivity.class);
            i.putExtra(DetalleActivity.EXTRA_TEXTO, c.getReceta());
            startActivity(i);
        }
    }
}