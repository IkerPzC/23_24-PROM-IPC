package com.example.ejerciciofragments;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class FragmentListado extends Fragment {
    private Plato[] datos = new Plato[] {
            new Plato("Lentejas", "5€","500 g. de lentejas pardinas extra\n4 zanahorias grandes\n2 dientes de ajo\n2 cebollas grandes\n1 hoja de laurel\n1 cucharada de pimentón de la Vera (dulce)\nSal y pimienta negra recién molida\n4 cucharadas de aceite de oliva virgen extra\n1 pimiento verde\n2 tomates grandes\n1 hueso de caña\n2 chorizos\n1 morcilla\n1/4 hueso de jamón\nAgua"),
            new Plato("Arroz negro","8€","300 g de Arroz bomba\n250 g de Gambas\n100 g de Cebolla\n1 Sepia\n2 Tomates\n2 Dientes de ajo\n50 g Pimiento verde italiano\nCaldo de pescado o fumet\n100 ml Vino blanco\nAceite de oliva virgen extra\n3 sobres Tinta de sepia o calamar "),
            new Plato("Hamburguesa barata","2€","2 Panes\n100g de Carne de vaca"),
            new Plato("Hamburguesa normal","6€","2 Panes\n200g de Carne de vaca\n2 Lonchas de Cheddar\n1 Tira de Bacon o Panceta"),
            new Plato("Hamburguesón","10€","2 Panes\n300g de Carne de vaca\n2 Lonchas de Cheddar\n2 Tira de Bacon o Panceta\n1 Huevo frito\nKetchup al corte\nMayonesa al corte\nMostaza al corte\n3 Pepinillos"),
            new Plato("Tortilla de patata sencilla (2 personas)","7€","4 Patatas\n4 Huevos\n250ml de Aceite de Oliva Virgen Extra\nSal"),
            new Plato("Tortilla de patata como dios manda (2 personas)","8€","5 Patatas\n5 Huevos\n1 Cebolla\n250ml de Aceite de Oliva Virgen Extra\nSal")
    };
    private ListView lstListado;
    private PlatoListener listener;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_listado, container, false);
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        lstListado = (ListView)getView().findViewById(R.id.lstListado);
        lstListado.setAdapter(new AdaptadorPlatos(this));
        lstListado.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                if (listener != null)
                    listener.onPlatoSeleccionado(
                            (Plato)lstListado.getAdapter().getItem(position));
            }
        });
    }

    public interface PlatoListener {
        void onPlatoSeleccionado(Plato p);
    }
    public void setPlatoListener(PlatoListener listener){
        this.listener =listener;
    }

    class AdaptadorPlatos extends ArrayAdapter<Plato> {
        Activity context;
        AdaptadorPlatos(Fragment context) {
            super(context.getActivity(), R.layout.listitem_plato, datos);
            this.context = context.getActivity();
        }

        @NonNull
        @Override
        public View getView(int position,
                            @Nullable View convertView,
                            @NonNull ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View item = inflater.inflate(R.layout.listitem_plato, null);
            TextView lblTitulo = (TextView) item.findViewById(R.id.lblTitulo);
            lblTitulo.setText(datos[position].getNombre());
            TextView lblDirector = (TextView)item.findViewById(R.id.lblDirector);
            lblDirector.setText(datos[position].getPrecio());
            return (item);
        }
    }
}