package com.example.ejerciciofragments;

public class Plato {
    private String nombre;
    private String precio;
    private String receta;

    public Plato(String nombre, String precio, String receta){
        this.precio = precio;
        this.receta = receta;
        this.nombre = nombre;
    }

    public String getPrecio() {
        return precio;
    }

    public String getReceta() {
        return receta;
    }

    public String getNombre() {
        return nombre;
    }
}
