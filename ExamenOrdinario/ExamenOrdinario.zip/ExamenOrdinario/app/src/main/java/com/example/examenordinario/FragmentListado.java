package com.example.examenordinario;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class FragmentListado extends Fragment {

    private Libro[] libros;
    private ListView lstListado;
    private LibroListener listener;
    private AdaptadorLibro adaptador;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_listado, container, false);
    }

    @Override
    public void onViewStateRestored(@Nullable Bundle savedInstanceState) {
        super.onViewStateRestored(savedInstanceState);
        lstListado = getView().findViewById(R.id.lstListado);
        adaptador = new AdaptadorLibro(this);

        libros = BibliotecaDAO.arrayLibros(new BibliotecaSQLiteHelper(getActivity(), "Biblioteca", null, 1));
        adaptador.actualizarLibros(libros);

        lstListado.setAdapter(adaptador);

        lstListado.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int position, long id) {
                if (listener != null)
                    listener.onLibroSeleccionado((Libro) lstListado.getAdapter().getItem(position));
                return true;
            }
        });
    }

    class AdaptadorLibro extends ArrayAdapter<Libro> {
        Activity context;

        AdaptadorLibro(Fragment context) {
            super(context.getActivity(), R.layout.fragment_listado_list);
            this.context = context.getActivity();
        }

        public void actualizarLibros(Libro[] nuevosLibros) {
            clear();
            addAll(nuevosLibros);
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public View getView(int position,
                            @Nullable View convertView,
                            @NonNull ViewGroup parent) {
            LayoutInflater inflater = context.getLayoutInflater();
            View item = inflater.inflate(R.layout.fragment_listado_list, null);
            TextView titulo = item.findViewById(R.id.titulo);
            titulo.setText(getItem(position).getTitulo());
            TextView autor = item.findViewById(R.id.autor);
            autor.setText(getItem(position).getAutor());
            return item;
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        actualizarLista();
    }

    public void actualizarLista() {
        libros = BibliotecaDAO.arrayLibros(new BibliotecaSQLiteHelper(getActivity(), "Biblioteca", null, 1));
        adaptador.actualizarLibros(libros);
    }

    public void setLibroListener(LibroListener listener) {
        this.listener = listener;
    }
}