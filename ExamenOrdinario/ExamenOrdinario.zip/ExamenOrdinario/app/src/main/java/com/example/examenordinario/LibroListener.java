package com.example.examenordinario;

public interface LibroListener {
    void onLibroSeleccionado(Libro l);

}