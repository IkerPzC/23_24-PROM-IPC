package com.example.examenordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class NuevoLibro extends AppCompatActivity {
    private Button insertar,cancelar,volver;
    private EditText titulo,autor,isbn,editorial;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_libro);

        //Instanciar variables
        insertar = findViewById(R.id.botonInsertar);
        cancelar = findViewById(R.id.botonCancelar);
        volver = findViewById(R.id.volverInsert);
        titulo = findViewById(R.id.titulo);
        autor = findViewById(R.id.autor);
        isbn = findViewById(R.id.isbn);
        editorial = findViewById(R.id.editorial);

        BibliotecaSQLiteHelper bibliotecaHelper = new BibliotecaSQLiteHelper(this, "Biblioteca", null, 1);

        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                limpiar();
            }
        });

        insertar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Validar que se han rellenado todos los campos
                if(!camposSinRellenar()){
                    //Si no existe un libro con el mismo isbn se inserta el libro
                    if(!new BibliotecaDAO().existeLibro(bibliotecaHelper,isbn.getText().toString())){
                        BibliotecaDAO bibliotecaDAO = new BibliotecaDAO();
                        bibliotecaDAO.nuevoLibro(bibliotecaHelper, isbn.getText().toString(), titulo.getText().toString(), autor.getText().toString(), editorial.getText().toString());
                        limpiar();
                        Toast.makeText(NuevoLibro.this, R.string.libro_add, Toast.LENGTH_SHORT).show();
                    }else{
                        Toast.makeText(NuevoLibro.this, R.string.libro_add_existente, Toast.LENGTH_SHORT).show();
                        isbn.setText("");
                    }
                }
                else{
                    Toast.makeText(NuevoLibro.this, R.string.libro_add_error, Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void limpiar() {
        titulo.setText("");
        autor.setText("");
        isbn.setText("");
        editorial.setText("");
    }

    private boolean camposSinRellenar(){
        if(titulo.getText().toString().trim().equals(""))
            return true;
        if(isbn.getText().toString().trim().equals(""))
            return true;
        if(autor.getText().toString().trim().equals(""))
            return true;
        if(editorial.getText().toString().trim().equals(""))
            return true;
        return false;
    }
}