package com.example.examenordinario;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class BibliotecaSQLiteHelper extends SQLiteOpenHelper {
    public BibliotecaSQLiteHelper(@Nullable Context context, @Nullable String name, @Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Creación de la tabla Libro
        db.execSQL(
                "CREATE TABLE Libro (" +
                        "isbn String PRIMARY KEY," +
                        "titulo TEXT," +
                        "autor TEXT," +
                        "editorial TEXT)");

        //Precargar base con 3 libros
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788490664322', 'El último apaga la luz', 'Nicanor Parra', 'Lumen')");
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788423351008', 'Los Pacientes del Doctor García', 'Alumdena Grandes', 'Tusquets editores')");
        db.execSQL(
                "INSERT INTO Libro (isbn, titulo, autor, editorial) " +
                        "VALUES ('9788499985954', 'Palmeras en la nieve', 'Luz Gabas', 'Temas de hoy')");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        db.execSQL("DROP TABLE IF EXISTS Libro");
        db.execSQL("CREATE TABLE Libro (" +
                "isbn String PRIMARY KEY," +
                "titulo TEXT," +
                "autor TEXT," +
                "editorial TEXT)");
    }
}