package com.example.examenordinario;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

public class BibliotecaDAO {

    //Insertar libro
    public boolean nuevoLibro(BibliotecaSQLiteHelper helper,String isbn,String titulo,String autor,String editorial) {

        SQLiteDatabase db = helper.getWritableDatabase();
        if (db != null){
                db.execSQL("INSERT INTO Libro " +
                        " VALUES ('"+isbn+"','"+titulo+"','"+autor+"','"+editorial+"') ");
        }
        db.close();
        return true;
    }

    //Borrar libro
    public boolean borrarLibro(BibliotecaSQLiteHelper helper, String isbn) {
        SQLiteDatabase db = helper.getWritableDatabase();
        boolean borradoExitoso = false;

        if (db != null) {
            int filasBorradas = db.delete("Libro", "isbn = ?", new String[]{isbn});
            if (filasBorradas > 0) {
                borradoExitoso = true;
            }
        }

        db.close();
        return borradoExitoso;
    }

    //Comprobar si existe libro en base al isbn
    public boolean existeLibro(BibliotecaSQLiteHelper helper, String isbn) {
        SQLiteDatabase db = helper.getReadableDatabase();
        boolean existe = false;

        if (db != null) {
            Cursor cur = db.rawQuery("SELECT * FROM Libro WHERE ISBN = ?", new String[]{isbn});

            if (cur != null && cur.moveToFirst()) {
                existe = true;
                cur.close();
            }
        }

        db.close();
        return existe;
    }

    //Devuelve cantidad de libros
    public int cuantosLibros(BibliotecaSQLiteHelper helper){
        int cuantos = 0;
        SQLiteDatabase db = helper.getReadableDatabase();
        if(db != null) {
            Cursor cur = db.rawQuery("SELECT * FROM Libro ", null);
            cuantos = cur.getCount();
            cur.close();
        }
        db.close();
        return cuantos;
    }

    //Array con los libros exsitentes en base de datos
    public static Libro[] arrayLibros(BibliotecaSQLiteHelper helper) {
        SQLiteDatabase db = helper.getReadableDatabase();
        Libro[] libros = new Libro[0];

        if (db != null) {
            Cursor cur = db.rawQuery("SELECT * FROM Libro ", null);
            libros = new Libro[cur.getCount()];

            int cont = 0;
            cur.moveToFirst();

            if(cur.isLast()){
                String isbn = cur.getString(0);
                String titulo = cur.getString(1);
                String autor = cur.getString(2);
                String editorial = cur.getString(3);

                Libro l = new Libro(isbn, titulo, autor, editorial);
                libros[cont] = l;
            }
            else{
                while(!cur.isLast()) {
                    String isbn = cur.getString(0);
                    String titulo = cur.getString(1);
                    String autor = cur.getString(2);
                    String editorial = cur.getString(3);

                    Libro l = new Libro(isbn, titulo, autor, editorial);
                    libros[cont] = l;
                    cont++;

                    cur.moveToNext();
                }

                String isbn = cur.getString(0);
                String titulo = cur.getString(1);
                String autor = cur.getString(2);
                String editorial = cur.getString(3);

                Libro l = new Libro(isbn, titulo, autor, editorial);
                libros[cont] = l;
            }

        }
        return libros;
    }
}