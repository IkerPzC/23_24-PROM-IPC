package com.example.examenordinario;

import android.util.Xml;
import org.xmlpull.v1.XmlPullParser;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

public class RssParser {

    public List<Noticia> parsearRSS(String url) throws Exception {
        List<Noticia> noticias = new ArrayList<>();
        XmlPullParser parser = Xml.newPullParser();
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);

        try (InputStream inputStream = new URL(url).openStream()) {
            parser.setInput(inputStream, null);
            int eventType = parser.getEventType();

            String titulo = null;
            String enlace = null;
            String fecha = null;

            while (eventType != XmlPullParser.END_DOCUMENT) {
                String name = parser.getName();

                switch (eventType) {
                    case XmlPullParser.START_TAG:
                        if (name.equals("item")) {
                            titulo = "";
                            enlace = "";
                        } else if (titulo != null) {
                            if (name.equals("title")) {
                                titulo = parser.nextText();
                            } else if (name.equals("link")) {
                                enlace = parser.nextText();
                            } else if (name.equals("pubDate")) {
                                fecha = parser.nextText();
                            }
                        }
                        break;

                    case XmlPullParser.END_TAG:
                        if (name.equals("item")) {
                            noticias.add(new Noticia(titulo, enlace, fecha));
                        }
                        break;
                }
                eventType = parser.next();
            }
        }

        return noticias;
    }
}