package com.example.examenordinario;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Html;
import android.view.View;
import android.widget.Button;

public class ListadoLibros extends AppCompatActivity implements LibroListener{
    public static Libro[] libros;
    private Button volver;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_listado_libros);

        volver = findViewById(R.id.botonV);
        libros = BibliotecaDAO.arrayLibros(new BibliotecaSQLiteHelper(this, "Biblioteca", null, 1));
        FragmentListado fragmentListado = (FragmentListado)getSupportFragmentManager().findFragmentById(R.id.frgListado);
        fragmentListado.setLibroListener(this);
        System.out.println(libros[0]);
        volver.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    @Override
    public void onLibroSeleccionado(Libro libro) {
        boolean hayDetalle = (getSupportFragmentManager().findFragmentById(R.id.frgDetalle)!= null);
        if (hayDetalle) {
            ((FragmentDetalle)getSupportFragmentManager().findFragmentById(R.id.frgDetalle)).mostrarDetalle(libro.getTitulo()+"\n"+libro.getAutor()+"\n"+libro.getIsbn()+"\n"+libro.getEditorial());
        }
        else {
            Intent i = new Intent(this, DetalleActivity.class);
            i.putExtra(DetalleActivity.EXTRA_TEXTO, libro.getTitulo()+"\n"+libro.getAutor()+"\n"+libro.getIsbn()+"\n"+libro.getEditorial());
            startActivity(i);
        }
    }
}