package com.example.examenordinario;

public class Noticia {
    //Variables
    private String titulo;
    private String enlace;
    private String fecha;

    //Constructor
    public Noticia(String titulo, String enlace, String fecha) {
        this.titulo = titulo;
        this.enlace = enlace;
        this.fecha = fecha;
    }

    //Getters
    public String getTitulo() {
        return titulo;
    }
    public String getEnlace() {
        return enlace;
    }
    public String getFecha() {
        return fecha;
    }
}