package com.example.examenordinario;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.io.InputStream;

public class NoticiaActivity extends AppCompatActivity {
    private Spinner spinnerLocalidades;
    private ExecutorService executorService;
    private RecyclerView recyclerView;
    private NoticiaAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_noticia);

        //Instanciar variables
        executorService = Executors.newSingleThreadExecutor();
        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        spinnerLocalidades = findViewById(R.id.spinnerLocalidades);

        //Cargar spinner
        cargarSpinner(leerFichero());

        spinnerLocalidades.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                //Obtener las URLs del archivo
                String[] urls = dameURL(getApplicationContext(), R.raw.url_noticias_comunidades);

                // Ejecutar Tarea Asíncrona
                if (i >= 0 && i < urls.length) {
                    ejecutarTareaAsincrona(urls[i]);
                }
            }

            private String[] dameURL(Context context, int rawResourceId) {
                ArrayList<String> arrListURL = new ArrayList<>();

                //Añadir urls del fichero
                for(String[] s:leerFichero()){
                    arrListURL.add(s[1]);
                }

                return arrListURL.toArray(new String[0]);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void ejecutarTareaAsincrona(String url) {
        executorService.submit(new Runnable() {
            @Override
            public void run() {
                try {
                    RssParser parser = new RssParser();
                    List<Noticia> noticias = parser.parsearRSS(url);
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            adapter = new NoticiaAdapter(noticias, NoticiaActivity.this);
                            recyclerView.setAdapter(adapter);
                        }
                    });
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }
    public void volver(View v) {
        Intent i = new Intent(NoticiaActivity.this, MainActivity.class);
        startActivity(i);
    }
    private void cargarSpinner(ArrayList<String[]> array) {
        ArrayList<String> lista = new ArrayList<>();

        for (String[] s : array) {
            lista.add(s[0]);
        }

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, lista);
        spinnerLocalidades.setAdapter(arrayAdapter);
    }
    public ArrayList<String[]> leerFichero(){ //O -> Localidad y 1 -> Url
        String[] partes;
        ArrayList<String[]> array = new ArrayList<String[]>();
        try {
            InputStream is = getResources().openRawResource(R.raw.url_noticias_comunidades);
            BufferedReader br = new BufferedReader( new InputStreamReader(is));
            String linea= br.readLine();
            while (linea!=null){
                //No se valida que el fichero siga el formato Localidad;Url
                partes = linea.split(";");
                array.add(partes);
                linea=br.readLine();
            }
            is.close();
        }
        catch (Exception ex) {
            Log.e ("FICHERO RAW", "ERROR - No se ha podido leer el fichero");  //R.string.debug_error_fichero
        }

        return array;
    }
}