package com.example.examenordinario;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NoticiaAdapter extends RecyclerView.Adapter<NoticiaAdapter.NoticiaViewHolder> {

    private List<Noticia> listaNoticias;
    private Context context;

    public NoticiaAdapter(List<Noticia> listaNoticias, Context context) {
        this.listaNoticias = listaNoticias;
        this.context = context;
    }

    @Override
    public NoticiaViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.news_item, parent, false);
        return new NoticiaViewHolder(view);
    }

    @Override
    public void onBindViewHolder(NoticiaViewHolder holder, int position) {
        Noticia noticia = listaNoticias.get(position);
        holder.tvTitulo.setText(noticia.getTitulo());
        holder.tvFecha.setText(noticia.getFecha());

        holder.tvTitulo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(noticia.getEnlace()));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listaNoticias.size();
    }

    public class NoticiaViewHolder extends RecyclerView.ViewHolder {
        TextView tvTitulo, tvFecha;

        public NoticiaViewHolder(View itemView) {
            super(itemView);
            tvTitulo = itemView.findViewById(R.id.tvTitle);
            tvFecha = itemView.findViewById(R.id.tvFecha);
        }
    }
}