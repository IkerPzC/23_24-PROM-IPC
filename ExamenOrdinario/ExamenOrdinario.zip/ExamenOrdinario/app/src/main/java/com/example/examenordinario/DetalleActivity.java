package com.example.examenordinario;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
public class DetalleActivity extends AppCompatActivity {
    public static final String EXTRA_TEXTO = "com.example.fragments.EXTRA_TEXTO";
    private Button cerrar, eliminar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalle2);
        FragmentDetalle detalle = (FragmentDetalle)getSupportFragmentManager().
                findFragmentById(R.id.frgDetalle);

        //Instanciar variables
        cerrar = findViewById(R.id.cancelarBtn);
        eliminar = findViewById(R.id.eliminar);

        eliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String isbn = getIntent().getStringExtra(EXTRA_TEXTO);

                BibliotecaSQLiteHelper bibliotecaHelper = new BibliotecaSQLiteHelper(getApplicationContext(), "Biblioteca", null, 1);
                BibliotecaDAO bibliotecaDAO = new BibliotecaDAO();

                if (bibliotecaDAO.borrarLibro(bibliotecaHelper, obtenerTextoISBN(isbn))) {
                    Toast.makeText(DetalleActivity.this, R.string.libro_delete, Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(DetalleActivity.this, R.string.libro_delete_error, Toast.LENGTH_SHORT).show();
                }

                finish();
            }
        });

        cerrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });

        detalle.mostrarDetalle(getIntent().getStringExtra(EXTRA_TEXTO));
    }

    public static String obtenerTextoISBN(String inputString) {
        //Obtener linea en posición 2 para formato -> titulo \n autor \n isbn \n editorial
        String[] lineas = inputString.split("\n");

        if (lineas.length >= 3) {
            return lineas[2];
        } else {
            return null;
        }
    }
}