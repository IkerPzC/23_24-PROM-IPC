package com.example.exameniker;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.ArrayList;

public class Localidades extends AppCompatActivity {

    // Array de objetos Localidad con datos predefinidos
    private final Localidad[] localidades = new Localidad[]{
            // Creación de instancias de Localidad con datos específicos
            new Localidad("Añana", "Araba", "Interior", "http://www.cuadrilladeanana.es/anana/", "anana.jpg"),
            new Localidad("Areatza", "Bizkaia", "Interior", "http://www.areatza.net", "areatza.jpg"),
            new Localidad("Astigarraga", "Gipuzkoa", "Interior", "http://astigarraga.eus", "astigarraga.jpg"),
            new Localidad("Balmaseda", "Bizkaia", "Costa", "http://www.balmaseda.net", "balmaseda.jpg"),
            new Localidad("Bermeo", "Bizkaia", "Costa", "http://www.bermeo.eus", "bermeo.jpg"),
            new Localidad("Donostia", "Gipuzkoa", "Costa", "http://www.donostia.eus", "donostia.jpg"),
            new Localidad("Gernika", "Bizkaia", "Interior", "http://www.gernika-lumo.net/", ""),
            new Localidad("Getxo", "Bizkaia", "Costa", "http://www.getxo.eus/", "getxo.jpg"),
            new Localidad("Hondarribia", "Gipuzkoa", "Costa", "http://www.hondarribia.eus.es/", "hondarribia.jpg"),
            new Localidad("Karrantza", "Bizkaia", "Interior", "http://www.karrantza.org/", "karrantza.jpg"),
            new Localidad("Laguardia", "Araba", "Interior", "http://www.laguardia-alava.net/", "laguardia.jpg"),
            new Localidad("Lekeitio", "Bizkaia", "Costa", "http://www.lekeitio.com/", "lekeitio.jpg"),
            new Localidad("Ondarroa", "Bizkaia", "Costa", "http://ondarroa.eu/", "ondarroa.jpg"),
            new Localidad("Orduña", "Bizkaia", "Interior", "http://www.urduna.com/", "orduna.jpg"),
            new Localidad("Pasaia", "Gipuzkoa", "Costa", "http://www.pasaia.eus/es", "pasaia.jpg"),
            new Localidad("Vitoria-Gasteiz", "Araba", "Interior", "http://www.vitoria-gasteiz.org/", "vitoria_gasteiz.jpg"),
            new Localidad("Zarautz", "Gipuzkoa", "Costa", "http://zarautz.org/", "zarautz.jpg")
    };

    private ArrayList<Localidad> localidadesDeProvincia;  // Lista de localidades de una provincia específica

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_localidades);
        getSupportActionBar().setTitle("LOCALIDADES CON ENCANTO");

        // Recuperar datos de la actividad anterior mediante Intent
        Bundle bundle = getIntent().getExtras();
        String provincia = bundle.getString("provincia");
        String ubicacion = bundle.getString("ubicacion");

        localidadesDeProvincia = new ArrayList<>();

        // Filtrar las localidades por provincia
        for (Localidad localidad : localidades) {
            if (localidad.getProvincia().equals(provincia)) {
                localidadesDeProvincia.add(localidad);
            }
        }

        // Actualizar el título de la actividad con la provincia y ubicación seleccionadas
        TextView textViewLocalidadTitle = findViewById(R.id.textViewLocalidadTitle);
        textViewLocalidadTitle.setText("---" + provincia + "---\n(" + ubicacion + ")");
    }

    // Método para regresar a la actividad anterior
    public void volver(View view) {
        finish();
    }
}