package com.example.exameniker;

import androidx.appcompat.app.AppCompatActivity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    // Método llamado cuando cambia la configuración del dispositivo
    public void onConfigurationChanged(Configuration config) {
        super.onConfigurationChanged(config);
    }

    // Método para mostrar un diálogo de despedida y cerrar la aplicación al hacer clic en el botón "Salir"
    public void salir(View view){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("ADIOS");
        builder.setMessage("Beti Alavés!!");
        builder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.show();
        AlertDialog alert = builder.create();
        alert.show();
    }

    // Método para iniciar la actividad del contador al hacer clic en el botón "Contador"
    public void contador(View view){
        Intent intent = new Intent(this, Contador.class);
        startActivity(intent);
    }

    // Método para iniciar la actividad del menú de localidades al hacer clic en el botón "Localidades"
    public void localidades(View view){
        Intent intent = new Intent(this, MenuLocalidad.class);
        startActivity(intent);
    }
}