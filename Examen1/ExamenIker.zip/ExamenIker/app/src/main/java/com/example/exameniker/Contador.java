package com.example.exameniker;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;

public class Contador extends AppCompatActivity {

    private int contador = 0;
    private TextView contadorActual;
    private CheckBox checkboxConteoNegativo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contador);

        // Inicializar los elementos de la interfaz de usuario
        contadorActual = findViewById(R.id.contadorActual);
        checkboxConteoNegativo = findViewById(R.id.checkboxConteoNegativo);
    }

    // Incrementar el contador en 1 y actualizar la interfaz de usuario
    public void sumarContador(View view) {
        contador++;
        actualizarContador();
    }

    // Decrementar el contador en 1 si la casilla de conteo negativo está marcada o el contador es mayor a 0
    // y actualizar la interfaz de usuario
    public void restarContador(View view) {
        if (checkboxConteoNegativo.isChecked() || contador > 0) {
            contador--;
            actualizarContador();
        }
    }

    // Resetear el contador con el valor ingresado en el cuadro de texto
    // Si no hay valor, establecer el contador en 0
    // Actualizar la interfaz de usuario y establecer el cuadro de texto a "0"
    public void resetearContador(View view) {
        EditText editText = findViewById(R.id.editText);
        String valorTexto = editText.getText().toString();

        if (!valorTexto.isEmpty()) {
            if (Integer.parseInt(valorTexto) < 0) {
                contador = 0;
            } else {
                contador = Integer.parseInt(valorTexto);
            }
        } else {
            contador = 0;
        }

        actualizarContador();
        editText.setText("0");
    }

    // Volver a la actividad anterior (MainActivity)
    public void volver(View view) {
        // Creamos un Intent para volver a MainActivity
        Intent intent = new Intent(this, MainActivity.class);

        // Iniciamos la actividad MainActivity
        startActivity(intent);

        // Cerramos la actividad actual (Contador)
        finish();
    }

    // Actualizar el contador en la interfaz de usuario y cambiar el color del texto
    // a negro si el contador es mayor o igual a 0, o a rojo si es negativo
    private void actualizarContador() {
        contadorActual.setText(String.valueOf(contador));

        // Cambiar el color del texto en función del valor del contador
        if (contador > -1) {
            contadorActual.setTextColor(Color.BLACK);
        } else {
            contadorActual.setTextColor(Color.RED);
        }
    }
}