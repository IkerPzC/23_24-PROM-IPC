package com.example.exameniker;

import java.io.Serializable;

public class Localidad implements Serializable {
    private String nombre;      // Nombre de la localidad
    private String provincia;   // Provincia de la localidad
    private String ubicacion;   // Ubicación de la localidad (Costa, Interior, etc.)
    private String enlace;      // Enlace relacionado con la localidad
    private String imagen;      // Nombre del archivo de imagen asociado

    // Constructor para inicializar una instancia de Localidad
    public Localidad(String nombre, String provincia, String ubicacion, String enlace, String imagen) {
        this.nombre = nombre;
        this.provincia = provincia;
        this.ubicacion = ubicacion;
        this.enlace = enlace;
        this.imagen = imagen;
    }

    // Métodos getter y setter para acceder y modificar los atributos privados

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    public String getEnlace() {
        return enlace;
    }

    public void setEnlace(String enlace) {
        this.enlace = enlace;
    }

    public String getImagen() {
        return imagen;
    }

    public void setImagen(String imagen) {
        this.imagen = imagen;
    }
}